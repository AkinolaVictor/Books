
Disktective 
Version: 4.0 

Short description: Freeware Disk reporting tool for Windows

Supported platforms: Windows 95, 98, ME, NT, 2000 and XP

License: Freeware for personal and coporate use

Release date: November 08, 2003

Created by: Freebyte.com, http://www.freebyte.com

Home page: http://www.freebyte.com/disktective

Newsletter: http://www.freebyte.com/newsletter

Feedback: http://www.freebyte.com/support


Files included in this package:
* Disktective.exe (the Disktective program)
* Readme.txt (this file)
* disktective_manual.hjt (the Disktective manual, TreePad format)
* disktective_manual.tpz (the Disktective manual, images)




MANUAL:
* The Disktective manual (included in this package) is in TreePad format. 
* To access the Disktective manual you can download a free reader program, called "TreePad Viewer". 
You can download the freeware TreePad Viewer from http://www.treepad.com/download/#tpview .
* The online version of the Disktective manual can be viewed in your Web browser, please see:
http://www.freebyte.com/disktective/manual/


What is disktective?

Disktective is a convenient freeware disk-reporting tool that enables you to find out the real size of your directories and distribution of used disk space.
 
Each directory on your harddisk may contain hundreds of subdirectories each of which can contain many files. To find the distribution of used space inside all of these directories, you need Disktective! 
 
Simply run Disktective and let the program create a complete report displaying the real sizes of all directories and their containing subdirectories.




Installing Disktective.

Simply copy the four files into a directory of your choice on your hard-disk. You can also run Disktective directly from a CD-rom or a floppy.


Optional installation instructions.
(adding an icon to a program-group)

Click the start-button on your screen with your right mouse-button and select 'open'. Then double-click the 'programs' group.
After that, double click the program group you want to install Disktective into. In that program group, RIGHT click an empty space inside the group with your mouse and select 'new' - 'shortcut'. Click the 'browse' button in 'Create Shortcut'. Browse to the directory where disktective resides on your disk. Then press the 'open' button and finish the process.


Disktective user-license
* Disktective is a freeware program, can be used without any limitations for personal and corporate use.


Disktective distribution license
* It is not allowed to change this package (the zip file). The Disktective zip package can be distributed freely on download Websites and CD-Roms. If you want to include Disktective on a shareware/freeware CD-Rom, this is allowed, but you can not charge any money for the program itself, because it is freeware.



